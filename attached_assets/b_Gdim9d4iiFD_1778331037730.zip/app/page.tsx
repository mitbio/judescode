import { DashboardLayout } from '@/components/dashboard-layout';
import { IntelligenceCardComponent } from '@/components/intelligence-card';
import { mockIntelligenceCards } from '@/data/mock-intelligence';

export default function Home() {
  return (
    <DashboardLayout>
      <div className="px-6 py-8 sm:px-8 max-w-7xl mx-auto">
        {/* Page Title */}
        <div className="mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-2">
            Intelligence Dashboard
          </h2>
          <p className="text-muted-foreground text-base sm:text-lg">
            Real-time insights and trend analysis for your content strategy
          </p>
        </div>

        {/* Bento Grid */}
        <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 auto-rows-max">
          {mockIntelligenceCards.map((card, index) => (
            <IntelligenceCardComponent key={card.id} card={card} index={index} />
          ))}
        </div>
      </div>
    </DashboardLayout>
  );
}
