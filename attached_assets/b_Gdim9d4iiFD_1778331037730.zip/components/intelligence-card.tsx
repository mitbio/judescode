'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, Share2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import type { IntelligenceCard } from '@/data/mock-intelligence';

interface IntelligenceCardProps {
  card: IntelligenceCard;
  index: number;
}

export function IntelligenceCardComponent({ card, index }: IntelligenceCardProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  const containerVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        delay: index * 0.08,
        ease: [0.25, 0.46, 0.45, 0.94],
      },
    },
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className={`group relative h-full rounded-3xl bg-card shadow-xl transition-all duration-300 hover:shadow-2xl overflow-hidden ${
        card.largeCard ? 'md:col-span-2 md:row-span-2' : ''
      }`}
    >
      {/* Card Content */}
      <div className="flex h-full flex-col p-6 sm:p-8">
        {/* Header with Badge */}
        <div className="mb-6 flex items-start justify-between">
          <div className="flex-1">
            <h3 className="text-lg sm:text-xl font-bold text-foreground text-balance">
              {card.hook}
            </h3>
          </div>

          {/* Live Trend Badge */}
          {card.badge && (
            <div className="ml-3 flex-shrink-0 inline-flex items-center gap-2 rounded-full bg-primary px-3 py-1 text-sm font-medium text-primary-foreground whitespace-nowrap">
              <span className="relative flex h-2 w-2">
                <span className="animate-pulse absolute inline-flex h-full w-full rounded-full bg-primary-foreground opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary-foreground"></span>
              </span>
              {card.badge}
            </div>
          )}
        </div>

        {/* Trend Value */}
        {card.trendValue && (
          <div className="mb-4 flex items-baseline gap-2">
            <span
              className={`text-2xl sm:text-3xl font-bold ${
                card.trend === 'up'
                  ? 'text-emerald-600 dark:text-emerald-400'
                  : card.trend === 'down'
                    ? 'text-rose-600 dark:text-rose-400'
                    : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              {card.trendValue}
            </span>
            <span className="text-sm text-muted-foreground capitalize">
              {card.trend === 'up' ? '↑ increase' : card.trend === 'down' ? '↓ decrease' : '→ stable'}
            </span>
          </div>
        )}

        {/* Narrative Section - Expandable */}
        <div className="flex-1 min-h-0">
          <motion.div
            animate={{ height: isExpanded ? 'auto' : '4.5rem' }}
            transition={{ duration: 0.3, ease: 'easeInOut' }}
            className="overflow-hidden"
          >
            <p className="text-sm sm:text-base text-muted-foreground leading-relaxed">
              {card.narrative}
            </p>
          </motion.div>
        </div>

        {/* Expand Button */}
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="mt-4 flex items-center gap-2 text-sm font-medium text-primary hover:text-primary/80 transition-colors self-start"
          aria-expanded={isExpanded}
          aria-label={`${isExpanded ? 'Collapse' : 'Expand'} narrative for ${card.hook}`}
        >
          <span>{isExpanded ? 'Less' : 'More'}</span>
          <ChevronDown
            size={16}
            className={`transition-transform duration-300 ${isExpanded ? 'rotate-180' : ''}`}
          />
        </button>

        {/* Push to Notion Button */}
        <div className="mt-6 pt-6 border-t border-border">
          <Button
            variant="outline"
            className="w-full gap-2 border-primary/30 text-primary hover:bg-primary/5 hover:border-primary/50 transition-colors"
            aria-label={`Push "${card.hook}" to Notion`}
          >
            <Share2 size={18} />
            Push to Notion
          </Button>
        </div>
      </div>

      {/* Subtle Glow on Hover */}
      <div className="absolute inset-0 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
        style={{
          background: 'radial-gradient(circle at 30% 30%, rgba(167, 139, 250, 0.1), transparent 80%)',
        }}
      />
    </motion.div>
  );
}
