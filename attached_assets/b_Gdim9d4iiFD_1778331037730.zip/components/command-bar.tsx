'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Zap } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

interface CommandBarProps {
  sidebarOpen?: boolean;
}

export function CommandBar({ sidebarOpen = true }: CommandBarProps) {
  const [searchValue, setSearchValue] = useState('');
  const [isHovering, setIsHovering] = useState(false);

  const handleRunIntelligence = () => {
    console.log('Running intelligence with niche:', searchValue);
    // Add actual functionality here
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.1 }}
      className={`sticky top-0 z-30 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80 border-b border-border transition-all duration-300 ${
        sidebarOpen ? 'ml-[280px]' : 'ml-[80px]'
      }`}
    >
      <div className="px-6 py-6 sm:px-8 relative">
        <div className="flex items-center justify-center gap-4 max-w-2xl mx-auto relative">
          {/* Search Input */}
          <div className="flex-1 relative group">
            <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
              <Search
                size={20}
                className="text-muted-foreground group-focus-within:text-primary transition-colors"
              />
            </div>
            <Input
              type="text"
              placeholder="Target Niche..."
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleRunIntelligence();
                }
              }}
              className="w-full pl-10 pr-4 py-3 rounded-xl border border-border bg-card text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
              aria-label="Search for target niche"
            />
          </div>

          {/* Run Intelligence Button */}
          <motion.div
            onHoverStart={() => setIsHovering(true)}
            onHoverEnd={() => setIsHovering(false)}
            className="relative"
          >
            <Button
              onClick={handleRunIntelligence}
              className={`gap-2 px-6 py-3 rounded-xl font-semibold text-primary-foreground transition-all duration-300 relative z-10 ${
                isHovering
                  ? 'bg-gradient-to-r from-primary to-accent shadow-lg'
                  : 'bg-primary hover:bg-primary/90'
              }`}
              aria-label="Run intelligence analysis"
            >
              <motion.div
                animate={{ rotate: isHovering ? 20 : 0 }}
                transition={{ duration: 0.2 }}
              >
                <Zap size={20} />
              </motion.div>
              <span className="hidden sm:inline">Run Intelligence</span>
              <span className="sm:hidden">Run</span>
            </Button>

            {/* Glow Effect Background */}
            <motion.div
              animate={{
                opacity: isHovering ? 0.5 : 0,
                scale: isHovering ? 1 : 0.9,
              }}
              transition={{ duration: 0.3 }}
              className="absolute -inset-8 w-56 h-20 bg-gradient-to-r from-primary to-accent rounded-full blur-3xl pointer-events-none -z-10"
            />
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
}
