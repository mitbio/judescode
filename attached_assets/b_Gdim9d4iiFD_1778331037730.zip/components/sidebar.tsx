'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Lightbulb, Calendar, Settings, ChevronLeft, ChevronRight } from 'lucide-react';
import { Slider } from '@/components/ui/slider';

interface SidebarProps {
  isOpen?: boolean;
  onToggle?: (open: boolean) => void;
}

export function Sidebar({ isOpen = true, onToggle }: SidebarProps) {
  const [aggressionLevel, setAggressionLevel] = useState([65]);
  const [sidebarOpen, setSidebarOpen] = useState(isOpen);

  const handleToggle = () => {
    const newState = !sidebarOpen;
    setSidebarOpen(newState);
    onToggle?.(newState);
  };

  const navItems = [
    {
      icon: Lightbulb,
      label: 'Content Brain',
      description: 'AI-powered content insights',
    },
    {
      icon: Calendar,
      label: 'Campaign Calendar',
      description: 'Schedule and track campaigns',
    },
    {
      icon: Settings,
      label: 'Intelligence Settings',
      description: 'Configure your dashboard',
    },
  ];

  return (
    <aside
      style={{
        width: sidebarOpen ? '280px' : '80px',
        transition: 'width 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94)',
      }}
      className="fixed left-0 top-0 h-screen bg-card border-r border-border flex flex-col shadow-lg z-40"
    >
      {/* Logo / Branding */}
      <div className="flex items-center justify-between p-6">
        <motion.div
          initial={false}
          animate={{ opacity: sidebarOpen ? 1 : 0, width: sidebarOpen ? 'auto' : 0 }}
          transition={{ duration: 0.2 }}
          style={{ overflow: 'hidden' }}
        >
          <h1 className="text-xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Intelligence
          </h1>
        </motion.div>
        <button
          onClick={handleToggle}
          className="ml-auto p-2 hover:bg-muted rounded-lg transition-colors"
          aria-label={sidebarOpen ? 'Collapse sidebar' : 'Expand sidebar'}
          aria-expanded={sidebarOpen}
        >
          {sidebarOpen ? <ChevronLeft size={20} /> : <ChevronRight size={20} />}
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 space-y-3 px-3">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <motion.button
              key={item.label}
              whileHover={{ x: sidebarOpen ? 4 : 0 }}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-muted transition-colors text-foreground"
              aria-label={item.label}
              title={item.label}
            >
              <Icon size={20} className="flex-shrink-0 text-primary" />
              <motion.div
                initial={false}
                animate={{ opacity: sidebarOpen ? 1 : 0, width: sidebarOpen ? 'auto' : 0 }}
                transition={{ duration: 0.2 }}
                style={{ overflow: 'hidden' }}
                className="text-left min-w-0"
              >
                <div className="font-medium text-sm truncate">{item.label}</div>
                <div className="text-xs text-muted-foreground truncate">{item.description}</div>
              </motion.div>
            </motion.button>
          );
        })}
      </nav>

      {/* Narrative Aggression Slider */}
      <motion.div
        animate={{ opacity: sidebarOpen ? 1 : 0.6 }}
        className="border-t border-border p-6 space-y-4"
      >
        <motion.div
          initial={false}
          animate={{ opacity: sidebarOpen ? 1 : 0, height: sidebarOpen ? 'auto' : 0 }}
          transition={{ duration: 0.2 }}
          style={{ overflow: 'hidden' }}
        >
          <label className="text-sm font-semibold text-foreground block mb-3">
            Narrative Aggression
          </label>
          <div className="space-y-3">
            <Slider
              value={aggressionLevel}
              onValueChange={setAggressionLevel}
              max={100}
              step={1}
              className="w-full"
              aria-label="Narrative aggression level"
            />
            <div className="flex justify-between items-center">
              <span className="text-xs text-muted-foreground">Conservative</span>
              <span className="text-sm font-bold text-primary">{aggressionLevel[0]}%</span>
              <span className="text-xs text-muted-foreground">Aggressive</span>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </aside>
  );
}
