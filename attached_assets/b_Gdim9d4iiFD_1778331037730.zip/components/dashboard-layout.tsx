'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Sidebar } from './sidebar';
import { CommandBar } from './command-bar';

interface DashboardLayoutProps {
  children: React.ReactNode;
}

export function DashboardLayout({ children }: DashboardLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className="min-h-screen bg-background">
      {/* Sidebar */}
      <Sidebar isOpen={sidebarOpen} onToggle={setSidebarOpen} />

      {/* Main Content - Using CSS instead of motion for stable layout */}
      <div
        style={{
          marginLeft: sidebarOpen ? '280px' : '80px',
          transition: 'margin-left 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94)',
        }}
        className="transition-all duration-300"
      >
        {/* Command Bar */}
        <CommandBar sidebarOpen={sidebarOpen} />

        {/* Page Content */}
        <main className="min-h-[calc(100vh-160px)]">
          {children}
        </main>
      </div>
    </div>
  );
}
