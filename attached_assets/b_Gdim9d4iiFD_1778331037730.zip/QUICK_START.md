# 🚀 Quick Start Guide - Soft SaaS Dashboard

## 📖 What You Built

A premium Next.js 14 dashboard with a "Soft SaaS" aesthetic featuring:
- 🎨 Elegant light theme with soft purple and pink accents
- 📱 Fully responsive bento grid layout
- ✨ Smooth Framer Motion animations
- 🧭 Collapsible sidebar with controls
- 🔍 Command bar with search and intelligence button
- 📊 Expandable intelligence cards with trends

## 🎯 Key Interactions

### Sidebar
- Click the chevron icon (left/right arrow) to toggle collapse/expand
- Drag the slider to adjust "Narrative Aggression" (0-100%)
- Click any navigation item to select it (currently mock)

### Intelligence Cards
- Click "More" / "Less" to expand/collapse the narrative section
- Hover over cards to see enhanced shadow effect
- Click "Push to Notion" to send the insight (currently mock)

### Command Bar
- Type in the search input to specify your "Target Niche"
- Press Enter or click "Run Intelligence" to execute search (currently mock)
- Hover over the button to see the glow effect

## 📂 File Structure

```
/app
  layout.tsx          # Root layout with metadata and fonts
  globals.css         # Soft SaaS theme tokens (HSL colors)
  page.tsx            # Main dashboard page with grid layout

/components
  dashboard-layout.tsx    # Layout wrapper (sidebar + command bar)
  sidebar.tsx             # Collapsible navigation sidebar
  command-bar.tsx         # Top search bar with action button
  intelligence-card.tsx   # Individual expandable card

/components/ui
  button.tsx          # Shadcn Button component
  input.tsx           # Shadcn Input component
  slider.tsx          # Shadcn Slider component

/data
  mock-intelligence.ts    # Sample intelligence card data

/tailwind.config.ts     # Tailwind configuration with theme
```

## 🎨 Customization Guide

### Change Colors
Edit `/app/globals.css` and update the HSL values in `:root`:
```css
:root {
  --primary: 270 92% 75%;        /* Soft Purple */
  --accent: 330 81% 68%;         /* Soft Pink */
  --background: 210 40% 98%;     /* Light Gray */
  /* ... */
}
```

### Modify Card Data
Edit `/data/mock-intelligence.ts` to change or add intelligence cards:
```typescript
{
  id: '9',
  hook: 'Your Title Here',
  narrative: 'Your narrative text here...',
  trend: 'up' | 'down' | 'neutral',
  trendValue: '+50%',
  badge: 'Live Trend',
  largeCard: false,
}
```

### Adjust Grid Layout
In `/app/page.tsx`, modify the grid classes:
```tsx
<div className="grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
  {/* Cards here */}
</div>
```

### Change Sidebar Width
In `/components/sidebar.tsx`, update the `animate` values:
```tsx
animate={{ width: sidebarOpen ? 280 : 80 }} // Change 280 or 80 for different widths
```

## 🔌 Connect Real Data

### Replace Mock Data with API
In `/app/page.tsx`:
```typescript
// Instead of:
import { mockIntelligenceCards } from '@/data/mock-intelligence';

// Do this:
const response = await fetch('/api/intelligence');
const intelligenceCards = await response.json();
```

### Implement "Run Intelligence"
In `/components/command-bar.tsx`, update `handleRunIntelligence`:
```typescript
const handleRunIntelligence = async () => {
  const response = await fetch('/api/search', {
    method: 'POST',
    body: JSON.stringify({ niche: searchValue }),
  });
  // Handle response...
};
```

### Implement "Push to Notion"
In `/components/intelligence-card.tsx`, update the button onClick:
```typescript
const handlePushToNotion = async () => {
  await fetch('/api/notion', {
    method: 'POST',
    body: JSON.stringify({ cardId: card.id }),
  });
};
```

## 💾 Environment Variables

Currently, no environment variables are required for the UI to work. When you add backend integration, you'll need:

```bash
# Create .env.local
NEXT_PUBLIC_API_URL=your-api-url
NOTION_API_KEY=your-notion-key
```

## 🧪 Development Commands

```bash
# Start dev server on http://localhost:3000
pnpm dev

# Build for production
pnpm build

# Start production server
pnpm start

# Type check
pnpm tsc --noEmit

# Format code (if Prettier configured)
pnpm format
```

## 📱 Responsive Breakpoints

The dashboard uses Tailwind's responsive prefixes:
- **Mobile**: Default (< 640px)
- **Tablet**: `sm:` prefix (640px+)
- **Desktop**: `lg:` prefix (1024px+)

Test by resizing your browser or using DevTools device emulation.

## ⌨️ Keyboard Shortcuts (Potential)

- `Enter` in search input → Run intelligence
- (Future) `Cmd/Ctrl + K` → Open command palette
- (Future) `Esc` → Close modals

## 🐛 Troubleshooting

### Cards not showing?
- Check `/data/mock-intelligence.ts` exports
- Verify imports in `/app/page.tsx`
- Check browser console for errors

### Sidebar not collapsing?
- Ensure `framer-motion` is installed (`pnpm add framer-motion`)
- Check that `DashboardLayout` is wrapping page content

### Styles not applying?
- Verify Tailwind config includes `/app/**/*.tsx`
- Check that `globals.css` is imported in layout
- Run `pnpm dev` to rebuild Tailwind CSS

### Port 3000 already in use?
```bash
# Kill process on port 3000
lsof -ti:3000 | xargs kill -9

# Or specify different port
pnpm dev --port 3001
```

## 📚 Additional Resources

- [Next.js Documentation](https://nextjs.org/docs)
- [Tailwind CSS](https://tailwindcss.com)
- [Framer Motion](https://www.framer.com/motion)
- [Lucide Icons](https://lucide.dev)
- [Shadcn/UI](https://ui.shadcn.com)

## 🎉 You're Ready!

Your premium Soft SaaS dashboard is now running. Visit http://localhost:3000 to see it in action!

### Next Steps:
1. Explore the dashboard and interact with components
2. Customize colors and styling to match your brand
3. Connect real data from your backend
4. Add user authentication
5. Deploy to Vercel with `pnpm deploy`

Enjoy! 🚀
