export interface IntelligenceCard {
  id: string;
  hook: string;
  narrative: string;
  trend: 'up' | 'down' | 'neutral';
  trendValue?: string;
  badge?: string;
  largeCard?: boolean;
}

export const mockIntelligenceCards: IntelligenceCard[] = [
  {
    id: '1',
    hook: 'Wellness Trends Surge 34%',
    narrative: 'Health and wellness content is experiencing unprecedented growth across all platforms. The category has seen 34% month-over-month increases in engagement, particularly in fitness, mental health, and nutrition niches.',
    trend: 'up',
    trendValue: '+34%',
    badge: 'Live Trend',
    largeCard: true,
  },
  {
    id: '2',
    hook: 'AI Integration Narrative Dominates',
    narrative: 'Artificial intelligence has become the central narrative in tech discussions. Content featuring AI tools, machine learning applications, and automation strategies are driving 2.3x higher engagement than traditional tech topics.',
    trend: 'up',
    trendValue: '+2.3x',
    badge: 'Live Trend',
  },
  {
    id: '3',
    hook: 'Sustainability Commitment Peak',
    narrative: 'Eco-conscious consumers are actively seeking sustainable brands. The sustainability narrative has grown to dominate 23% of all consumer-focused content, with an upward trajectory expected to continue.',
    trend: 'up',
    trendValue: '+23%',
    badge: 'Live Trend',
  },
  {
    id: '4',
    hook: 'Remote Work Culture Evolving',
    narrative: 'The remote work narrative is shifting from novelty to standard practice. Companies embracing hybrid models are seeing 18% higher talent retention rates and increased employee satisfaction metrics.',
    trend: 'neutral',
    trendValue: '±18%',
    badge: 'Live Trend',
  },
  {
    id: '5',
    hook: 'Creator Economy Expansion',
    narrative: 'Content creators are becoming primary influencers in their niches. The creator economy has grown to $104 billion annually, with an 41% year-over-year growth rate in creator-backed commerce.',
    trend: 'up',
    trendValue: '+41%',
    badge: 'Live Trend',
    largeCard: true,
  },
  {
    id: '6',
    hook: 'Privacy-First Marketing Shift',
    narrative: 'Consumers prioritize privacy over personalization in 67% of responses. Brands adopting privacy-first marketing strategies are building stronger customer trust and loyalty while complying with new regulations.',
    trend: 'up',
    trendValue: '+67%',
    badge: 'Live Trend',
  },
  {
    id: '7',
    hook: 'Voice Search Optimization Rising',
    narrative: 'Voice-activated search queries have increased 45% in the past year. Brands optimizing for conversational keywords are capturing early-mover advantages in this emerging search paradigm.',
    trend: 'up',
    trendValue: '+45%',
    badge: 'Live Trend',
  },
  {
    id: '8',
    hook: 'Micro-Community Building Trend',
    narrative: 'Niche communities are outperforming mass-market channels. Small, engaged communities show 5x higher conversion rates and stronger brand loyalty compared to broader audience strategies.',
    trend: 'up',
    trendValue: '+5x',
    badge: 'Live Trend',
  },
];
