# Soft SaaS Premium Dashboard - Implementation Guide

## Overview
A premium Next.js 14 dashboard with a "Soft SaaS" aesthetic featuring a collapsible sidebar, command bar, and responsive bento grid layout for intelligence cards.

## Architecture

### Components
- **`/components/dashboard-layout.tsx`** - Main layout wrapper with sidebar and command bar
- **`/components/sidebar.tsx`** - Collapsible navigation sidebar with "Narrative Aggression" slider
- **`/components/command-bar.tsx`** - Top command bar with search input and "Run Intelligence" button
- **`/components/intelligence-card.tsx`** - Individual card component with expandable narrative section
- **`/app/page.tsx`** - Main dashboard page with bento grid layout

### Data
- **`/data/mock-intelligence.ts`** - Mock intelligence card data with TypeScript types

### Styling
- **`/app/globals.css`** - Soft SaaS theme with HSL color tokens
- **`/tailwind.config.ts`** - Tailwind configuration with custom colors and fonts

## Design System

### Color Palette (Light Theme)
- **Background**: `#F9FAFB` (light gray)
- **Card**: `#FFFFFF` (pure white)
- **Primary**: `#A78BFA` (soft purple)
- **Accent**: `#F472B6` (soft pink)
- **Foreground**: `#1F2937` (dark gray)

### Typography
- **Fonts**: Inter & Plus Jakarta Sans (imported from Google Fonts)
- **Base**: 16px with 1.5rem line-height for body text

### Radius
- **Cards**: `rounded-3xl` (1.5rem)

## Key Features

### Intelligence Cards
- ✨ Framer Motion entrance animations with staggered delay
- 🏷️ "Live Trend" badge with pulsing indicator
- 📈 Trend values with directional indicators (up/down/neutral)
- 📖 Expandable narrative section with smooth transitions
- 🚀 "Push to Notion" button at bottom

### Sidebar
- 🔄 Collapsible with smooth width transitions (280px ↔ 80px)
- 🧭 Navigation items: Content Brain, Campaign Calendar, Intelligence Settings
- 🎚️ Narrative Aggression slider (0-100%)
- 🎨 Icons from Lucide React

### Command Bar
- 🔍 Centered search input with icon
- ⚡ "Run Intelligence" button with gradient and glow effect on hover
- 📱 Responsive design (full "Run Intelligence" on desktop, "Run" on mobile)
- 🌟 Animated glow background on hover

## Responsive Layout

### Bento Grid
- **Desktop (1024px+)**: 3-column grid with mixed card spans
- **Tablet (640px-1023px)**: 2-column grid
- **Mobile (<640px)**: 1-column stack

Cards are rendered with:
```tsx
grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 auto-rows-max
```

Some cards have `largeCard: true` to span 2 columns and 2 rows on desktop.

## Animations

### Framer Motion
- **Card entrance**: Fade in + slide up over 0.6s with easing
- **Stagger delay**: `index * 0.08` seconds
- **Narrative expand**: Height animation over 0.3s
- **Sidebar collapse**: Width animation over 0.3s
- **Button hover**: Gradient background and glow effect

## State Management
- **Per-card expansion state**: `useState` in `IntelligenceCardComponent`
- **Sidebar toggle**: Passed via `DashboardLayout` to control sidebar width
- **Narrative aggression**: Stored in `Sidebar` component state

## Accessibility
- Semantic HTML (`<nav>`, `<main>`, `<button>`)
- ARIA labels on interactive elements
- Focus states via Tailwind `focus:ring-2`
- Proper heading hierarchy

## Development

### Start Dev Server
```bash
pnpm dev
```

The dashboard will be available at `http://localhost:3000`

### Build for Production
```bash
pnpm build
pnpm start
```

## Dependencies
- `framer-motion`: Smooth entrance animations
- `lucide-react`: SVG icons
- `shadcn/ui`: Pre-built components (Button, Input, Slider)
- `tailwindcss`: Utility-first CSS
- `next`: React meta-framework

## Future Enhancements
- API integration for real intelligence data
- Notion webhook integration for "Push to Notion"
- Real-time trend updates via WebSockets
- User authentication and preferences
- Dark mode toggle
- Export functionality for insights
